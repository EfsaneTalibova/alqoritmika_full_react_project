import './App.css';
import Counter from './Counter';
function App() {


  return (
    <div> 
 <Counter/>
  
    </div>
    
  );
}

export default App;
